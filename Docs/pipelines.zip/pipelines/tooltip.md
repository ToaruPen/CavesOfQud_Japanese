# Tooltip パイプライン仕様 v1

> **画面 / 部位:** Looker / 右クリック Tooltip / インベントリ hover  
> **出力:** Unity (ModelShark.TooltipTrigger + TMP)

## 概要

- Tooltip の本文は `XRL.UI.Look.GenerateTooltipContent`（gameQueue）で構築し、UI 側では `TooltipTrigger.SetText("BodyText", RTF.FormatToRTF(...))` に渡す。
- `TooltipInformation` 構造体で DisplayName / SubHeader / WoundLevel / LongDescription / Icon が一括管理される。
- ContextID 例: `XRL.UI.Look.GenerateTooltipContent.Body`, `XRL.UI.Look.GenerateTooltipInformation.SubHeader`, `ModelShark.TooltipTrigger.SetText.TooltipField`.

## 主なクラス / メソッド

| フェーズ | クラス | メソッド / 備考 |
| --- | --- | --- |
| 生成 | `XRL.UI.Look` | `GenerateTooltipInformation`（`Description.GetLongDescription`, `Strings.WoundLevel` などを結合）。 |
| 整形(文字列化) | `XRL.UI.Look` | `GenerateTooltipContent` が `StringBuilder` → `Markup.Transform` を実施。 |
| 非同期橋渡し | `GameManager.Instance.gameQueue` | `executeAsync(() => GenerateTooltipContent())` でゲームデータを取得。 |
| 整形(RTF) | `Sidebar.FormatToRTF` / `RTF.FormatToRTF` | 文字列を RichText（幅 ~60, フォントカラー `FF`）へ変換。 |
| 描画 | `ModelShark.TooltipTrigger` | `SetText` → `TMP_Text` へセットし、`ShowManually` で表示。 |

## データフロー

1. `Look.ShowItemTooltipAsync` が `gameQueue.executeAsync` で `GenerateTooltipContent(go)` を実行（Thread: `gameQueue`）。
2. Game スレッドで `TooltipInformation` を構築 → `StringBuilder` に DisplayName / LongDescription / SubHeader / WoundLevel を順に `AppendLine`。
3. `Markup.Transform` で色タグを適用した文字列を返却。
4. UI スレッド (`await The.UiContext`) で `RTF.FormatToRTF(contents)` もしくは `Sidebar.FormatToRTF(contents, "FF", 60)` を通し、TMP RichText に変換。
5. `TooltipTrigger.SetText("BodyText", ...)` が文字列を TMP に与え、`tooltip.ShowManually` が位置調整・表示。
6. `TooltipTrigger.onHideAction` が `gameQueue.queueTask` を発行し、`AfterLookedAt` などのイベントを発火。

## 整形規則

- `GenerateTooltipContent`: DisplayName → blank line → LongDescription → blank line ×2 → SubHeader → WoundLevel。  
  行順が固定なので、翻訳時も同じ構成・改行数を維持する。
- `RTF.FormatToRTF(..., "FF", 60)` で **幅 60 文字** を前提とした折り返しが行われ、色はデフォルトで #FFFF00 にマップ。
- `TooltipTrigger` は TMP RichText を解釈。`<color=#FF>` 系タグは `RTF.FormatToRTF` 側で生成されるので、翻訳側で `<color>` を追加する必要はない。
- `TooltipInformation.SubHeader` は `FeelingText` + `DifficultyText` を `", "` 連結する。個別翻訳にしたい場合は `SubHeader.Feeling`, `.Difficulty` を ContextID として分岐させる。

## 同期性

- 生成 (`GenerateTooltipInformation` / `Content`) は `gameQueue` 専用。ここで UI オブジェクトに触るとクラッシュする。
- 描画 (`TooltipTrigger.SetText`) は `uiQueue`（`The.UiContext` or `GameManager.Instance.uiQueue.queueTask`）で実行。
- 翻訳処理を入れるときは **どちらのキューで呼ばれるか**を ContextID 名に含める（例: `Look.GenerateTooltipContent.Body` vs `TooltipTrigger.SetText.Body`）。

## 置換安全点（推奨フック）

- `Harmony Prefix: XRL.UI.Look.GenerateTooltipInformation`  
  - ContextID: `XRL.UI.Look.GenerateTooltipInformation.DisplayName` など。  
  - 長文・短文を分割して保持できる。各フィールドが再利用されるため、再フォーマット時の重複を防げる。
- `Harmony Prefix: XRL.UI.Look.GenerateTooltipContent`  
  - ContextID: `XRL.UI.Look.GenerateTooltipContent.Body`.  
  - SubHeader / LongDescription をまとめて処理したい場合はこちらで翻訳し、`Markup.Transform` 前に差し込む。
- `Harmony Prefix: ModelShark.TooltipTrigger.SetText`（バックアップ）  
  - ContextID: `ModelShark.TooltipTrigger.SetText.TooltipField`.  
  - RTF 変換後の文字列を直接差し替える最終手段。ただし RTF 表現（`{\rtf1...}`）の制約が厳しいため、極力避ける。

## 例文 / トークン

- DisplayName: `"{{G|" + go.BaseDisplayName + "}}"`  
- LongDescription: `Description.GetLongDescription` 由来で `{{d|...}}` タグを含む。  
- SubHeader: `"neutral, average"` のような `Feeling, Difficulty` テキスト。  
- 特殊 Tooltip: `Look.QueueLookerTooltip` では `ParameterizedTextField` (`DisplayName`, `ConText`, `WoundLevel`, `LongDescription`) の各フィールドに別々の RTF を流し込む。

## リスク

- `GenerateTooltipContent` 内の行順前提が崩れると `TooltipTrigger` レイアウトが期待通りに更新されない（空行自体が UI のスペーサとして使われる）。
- `RTF.FormatToRTF` は制御文字（`\`）をエスケープするため、翻訳が追加した `\` を二重化しないよう注意。
- `TooltipTrigger` は再利用キャッシュがあるため、翻訳した文字列に `StringBuilder` を保持させると GC コストが増す。常に `string` で返す。

## テスト手順

1. ゲーム内で `l` (Look) → 任意のオブジェクトをターゲット。UI Tooltip が翻訳済みか、SubHeader が想定通りか確認。
2. インベントリ画面でアイテムにマウス hover。`Look.ShowItemTooltipAsync` パスで `RTF.FormatToRTF` が崩れないかチェック。
3. `Player.log` に `TooltipTrigger` / `TMP` の RichText エラーが出ていないか監視。
4. `Translator/JpLog` で `ContextID=Look.GenerateTooltipContent.Body` のヒット数を確認し、未翻訳が残る場合はキー正規化を追加。
