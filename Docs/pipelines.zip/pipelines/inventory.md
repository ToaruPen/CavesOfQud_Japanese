# Inventory / Equipment パイプライン仕様 v1

> **画面 / 部位:** インベントリ＋装備管理  
> **出力:** Console（`InventoryScreen`） / Unity（`InventoryAndEquipmentStatusScreen`）

## 概要

- **クラシック UI**（`Options.ModernUI=false` または `ModernCharacterSheet=false`）では `XRL.UI.InventoryScreen` が `ScreenBuffer` 上にカテゴリ一覧・アイテム行・重量を描画する。
- **Modern UI** では `Qud.UI.InventoryAndEquipmentStatusScreen` が StatusScreens 内のタブとして表示され、`InventoryLine` / `EquipmentLine` の `UITextSkin` を経由して TextMeshPro にリッチテキストを流し込む。
- 双方とも `GameObject.DisplayName`（Markup を含む）を基礎にしており、翻訳は DisplayName / カテゴリ名 / UI ラベルに挿入する。

## 主なクラス / メソッド

| フェーズ | クラシック (Console) | Modern UI (Unity) |
| --- | --- | --- |
| 生成 | `InventoryScreen.RebuildLists` が `GameObject.Inventory` の内容をカテゴリ別に構築 (`CategoryMap`, `CategorySelectionList`) | `InventoryAndEquipmentStatusScreen.UpdateViewFromData` が `InventoryLineData` のリストを生成 (`GO.Inventory.Objects`, `filterBar`, `categoryWeight` 等) |
| 整形 | `ScreenBuffer.Write` へ渡す直前に `StringBuilder` で `{{K|[Category]}}`, `key)` 等の Markup を組み立て。重量は `{{Y|}}` 付き | `InventoryLine.setData` が `UITextSkin.SetText` で `categoryLabel`, `itemWeightText`, `text` を更新。`UITextSkin` 内部で `ToRTFCached` → TMP RichText |
| 描画 | `ScreenBuffer.SingleBox` + `ScreenBuffer.Write`; 行の左右に `ColorUtility.LengthExceptFormatting` で位置合わせ | `FrameworkScroller.BeforeShow` が `InventoryLine` プールを回し、`UITextSkin`（TMP）へ適用。Equipment パネルは `EquipmentLineData` 経由 |
| 付帯情報 | `InventoryScreen.Show` が「Total weight」「items hidden by filter」等を `StringBuilder` で生成 | `InventoryAndEquipmentStatusScreen.weightText` / `priceText` が `{{C|...}}` など Markup 付き文字列を `UITextSkin` に渡し、TMP で表示 |

## データフロー

### Console (`InventoryScreen`)
1. `RebuildLists(GO)` が `inventory.GetObjectsDirect()` を走査し、`CategoryMap` / `SelectionList` を構築（フィルタと `GameObject.GetInventoryCategory()` で分類）。
2. カテゴリ行は `CategorySelectionList.Add(hotkey, new CategorySelectionListEntry(...))` の形で保持。各カテゴリに `Weight` / `Items` を集計。
3. `Show` ループ内で `Buffer.Write(" > key) ...")` としてカテゴリ／アイテム行を描画。`gameObject.DisplayName` は Markup を含んだまま `ScreenBuffer` へ渡る。
4. 右端の重量列は `StringBuilder.Append(" {{K|12#}}")` 等で作成。合計重量は `Buffer.Goto(79 - LengthExceptFormatting(...))` で右寄せ。
5. ユーザー操作（Drop/Eat/Filterなど）は `Keyboard.getvk` で処理。選択された行に応じて `InventoryActionEvent.Check` を呼び、必要に応じ `ResetNameCache`。

### Modern UI (`InventoryAndEquipmentStatusScreen`)
1. `UpdateViewFromData` で `GO.Inventory.Objects` を列挙し、`InventoryLineData` プールを取得 → カテゴリ別に `objectCategories` へ格納。`filterBar` / `SearchMode` で絞り込み。
2. カテゴリ行は `InventoryLineData.set(category: true, ...)` で `categoryName`, `categoryWeight`, `categoryAmount` を保持。アイテム行は `displayName = go.DisplayName` を lazily 取得。
3. `inventoryController.BeforeShow(listItems)` がスクロール UI に行データをバインド。各 `InventoryLine` が `setData` 内で `UITextSkin.SetText` を呼んで TMP RichText 化。
4. 装備欄 (`equipmentPaperdollController`, `equipmentListController`) も同様に `EquipmentLineData` → `UITextSkin`。ドラッグ & ドロップやホットキーも `InventoryLine` に集約。
5. 表示用ラベル: `priceText.SetText("{{B|$NN}}")`, `weightText.SetText("{{C|carried{{K|/max}} lbs.}}")`。`UITextSkin` が `ToRTFCached`（= `RTF.FormatToRTF` + キャッシュ）で TMP 互換表現に変換。

## 整形規則

- Console:
  - 幅 80 × 25 前提。カテゴリ一覧は画面左から `"> key) [+] {{K|[Name, N items]}}"` 形式。`ColorUtility.LengthExceptFormatting` を使って右端の重量列を合わせる。
  - アイテム行の終端は `Buffer.Write(stringBuilder8)` で `{{K|12#}}`（重量 + 単位）を `80 - length` の位置に描画。
  - 合計重量行も `{{Y|carried}} {{y|/}} {{currentMaxWeight}} lbs.` として Markup 付与。折り返しは `ScreenBuffer` 側で行わないため、翻訳は 1 行で収める。
- Unity:
  - `UITextSkin` が `text.ToRTFCached(blockWrap)` で `<color=#RRGGBBAA>` 等の RichText へ変換。`useBlockWrap=true` なら `TextBlock` 相当の幅制限（既定 72）を適用。
  - カテゴリ重量テキストは `categoryWeightText.SetText($"|{amount} items|{weight} lbs.|")` のように `|` 記号を区切りに使い、スキン内部で等幅風に表示される。
  - アイテム重量は `"[123 lbs.]"` の固定パターン。翻訳で単位位置を変える場合は `[]` の括弧や数値部分を保持する。

## 同期性

- どちらも **ゲームスレッド (sync)** で実行。`InventoryScreen.Show` は `GameManager.Instance.PushGameView("Inventory")` でループし、`Keyboard.getvk` を直読みする。
- Modern UI も `StatusScreensScreen`（Unity）内で動くが、`UpdateViewFromData` はゲームスレッドでリストを構築し、その後 `UITextSkin` が `Apply()` するときに UI スレッドへ反映される。翻訳フックはゲームスレッド側（`InventoryLineData.displayName` 生成時など）で差し込むのが安全。

## 置換安全点（推奨フック）

- `GameObject.DisplayName` / `InventoryLineData.displayName`  
  - ContextID: `XRL.World.GameObject.DisplayName.Inventory`.  
  - DisplayName は両 UI が共有するので、ここで翻訳すれば Console/Unity 一括で反映。
- `XRL.UI.InventoryScreen.RebuildLists`（カテゴリラベル, フィルタメッセージ）  
  - ContextID: `XRL.UI.InventoryScreen.Category.Name`, `InventoryScreen.Show.TotalWeight`, など。  
  - `StringBuilder` で直接英語文を作っている箇所を置き換える。
- `Qud.UI.InventoryAndEquipmentStatusScreen.UpdateViewFromData`  
  - ContextID: `Qud.UI.InventoryAndEquipmentStatusScreen.CategoryLabel`, `.WeightText`, `.PriceText`.  
  - `SetText` に渡すフォーマット文字列をここで翻訳する。`{{` `}}` / `[]` / `|` は UI ロジックが前提にしているため崩さない。
- `Qud.UI.InventoryLine.setData`  
  - ContextID: `Qud.UI.InventoryLine.CategoryToggle`, `.ItemWeightLabel`.  
  - カテゴリ `[+]` / `[-]` など UI テキストを変更したい場合に利用。

## 例文 / トークン

- カテゴリ: `"> a) [+] {{K|[{{Y|Weapons}}, 5 items]}}"`  
- アイテム行: `"   b) dagger"` + `" {{K|2#}}"`（右端）  
- Total weight: `"Total weight: {{Y|125}} {{y|/}} 250 lbs."`  
- Modern UI weight: `weightText = "{{C|135{{K|/200}} lbs. }}"`  
- Modern UI price: `priceText = "{{B|$45}}"`  
- カテゴリ重量: `categoryWeightText = "|3 items|24 lbs.|"`

## リスク

- Console 版はハードコーディングされた位置合わせに依存するため、訳文が長いと右端の重量列が潰れる。特にカテゴリ行（`Buffer.Goto(79 - length, y)`）は 80 列制限がシビア。
- Modern UI のカテゴリラベルは `hotkey)` と `[-]` / `[+]` を含んでいる。翻訳で順序を変えるとキーヒント解析（`dictionary.Add(key, num)`) とズレるので注意。
- `UITextSkin` の `blockWrap` は既定 72。長文を差し込むと TMP で自動折り返しされるが、`HotkeySpread` の位置やアイコンとの横幅計算が崩れる可能性がある。
- 価格／重量ラベルは `{{...}}` を複数ネストしている。翻訳時に波括弧を崩すと `ToRTFCached` のキャッシュキーが変わり、RichText が壊れる。

## テスト手順

1. **クラシック UI**: `Options.ModernUI=false` でゲームを起動し、`i`（Inventory）を開く。カテゴリ展開/折り畳み、重量表示、フィルタ (`Ctrl+F`) を操作して文言とレイアウトを確認。
2. **Modern UI**: `Options.ModernUI=true` でキャラクター画面 (`Esc` → Character / Equipment) を開き、StatusScreens 内の「Equipment」タブをチェック。カテゴリ collapsible、検索、トグル（Paperdoll/List）を操作しながら翻訳が崩れないか確認。
3. `priceText` / `weightText` / `categoryWeightText` が TMP RichText エラーを出していないか `Player.log` を確認。
4. `Translator/JpLog` に ContextID を追加し、カテゴリ名・重量ラベルのヒット状況を収集して抜け漏れを検出。
